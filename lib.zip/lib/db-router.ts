// lib/db-router.ts
// Drop-in database router.
//
// ALL existing code using `prisma` from "@/lib/prisma" continues to work
// exactly as before — do not change any existing imports.
//
// Only NEW code (register route + any new routes you write) uses getDb().
// Existing users are all in the primary database and existing routes find
// them fine through the original prisma import.

import { PrismaClient } from '@prisma/client'
import { prisma }       from '@/lib/prisma'   // your existing primary client

// ── Secondary database client ─────────────────────────────────────────────────

const globalForPrisma2 = globalThis as unknown as { prisma2: PrismaClient | undefined }

export const prisma2 = globalForPrisma2.prisma2 ?? new PrismaClient({
  datasources: { db: { url: process.env.DATABASE_URL_2 } },
})

if (process.env.NODE_ENV !== 'production') globalForPrisma2.prisma2 = prisma2

// ── Route a user to their database ───────────────────────────────────────────
// Checks primary first (all existing users live here).
// Falls back to secondary for new users saved there.
// Returns your existing `prisma` client or `prisma2` — same interface, works identically.

export async function getDb(userId: string): Promise<PrismaClient> {
  // Check primary database first — all existing users are here
  const inPrimary = await prisma.user.findUnique({
    where:  { id: userId },
    select: { id: true },
  }).catch(() => null)

  if (inPrimary) return prisma

  // Check secondary database
  const inSecondary = await prisma2.user.findUnique({
    where:  { id: userId },
    select: { id: true },
  }).catch(() => null)

  if (inSecondary) return prisma2

  // Default to primary if not found (safety fallback)
  return prisma
}

// ── Pick database for a new registration ─────────────────────────────────────
// Counts users in both and picks the one with fewer.

export async function getDbForNewUser(): Promise<PrismaClient> {
  if (!process.env.DATABASE_URL_2) return prisma  // secondary not configured yet

  const [count1, count2] = await Promise.all([
    prisma.user.count().catch(() => 0),
    prisma2.user.count().catch(() => 0),
  ])

  return count2 < count1 ? prisma2 : prisma
}