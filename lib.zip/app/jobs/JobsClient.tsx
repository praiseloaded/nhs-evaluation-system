'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import {
  Search, MapPin, Stethoscope, Loader2, ExternalLink, Sparkles,
  Calendar, PoundSterling, AlertCircle, ChevronLeft, ChevronRight,
  Clock, FileText, Building2, Car, Award, HeartPulse, Globe,
  ArrowRight,
} from 'lucide-react'
import { ThemeSwitcher } from '@/components/theme-switcher'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'




interface Job {
  title: string; employer: string; location: string; salary: string
  datePosted: string; closingDate: string; contractType: string
  workingPattern: string; jobRef: string; url: string
}

interface SponsorInfo {
  isMatch: boolean
  confidence: 'high' | 'medium' | 'low' | 'none'
  matchedName?: string
  rating?: string
  townCity?: string
}

function getInitials(name: string) {
  return name
    .split(' ')
    .filter(w => w.length > 2)
    .slice(0, 3)
    .map(w => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 3)
}

// Five colour ramps mapped to avatar backgrounds — colour encodes org identity, not sequence
const avatarRamps = [
  { bg: 'bg-[#E6F1FB] dark:bg-[#0C447C]', text: 'text-[#0C447C] dark:text-[#B5D4F4]' }, // blue
  { bg: 'bg-[#E1F5EE] dark:bg-[#085041]', text: 'text-[#085041] dark:text-[#9FE1CB]' }, // teal
  { bg: 'bg-[#EEEDFE] dark:bg-[#3C3489]', text: 'text-[#3C3489] dark:text-[#CECBF6]' }, // purple
  { bg: 'bg-[#FAEEDA] dark:bg-[#633806]', text: 'text-[#633806] dark:text-[#FAC775]' }, // amber
  { bg: 'bg-[#FAECE7] dark:bg-[#712B13]', text: 'text-[#712B13] dark:text-[#F5C4B3]' }, // coral
]

function getAvatarRamp(str: string) {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) & 0xffff
  return avatarRamps[h % avatarRamps.length]
}

function isClosingSoon(closingDate: string) {
  try {
    const d = new Date(closingDate)
    const diff = (d.getTime() - Date.now()) / 86400000
    return diff >= 0 && diff <= 7
  } catch { return false }
}

function isNew(datePosted: string) {
  try {
    const d = new Date(datePosted)
    return (Date.now() - d.getTime()) / 86400000 <= 3
  } catch { return false }
}

function JobCard({ job, isLoggedIn, cosMode, sponsorInfo }: { job: Job; isLoggedIn: boolean; cosMode: boolean; sponsorInfo?: SponsorInfo }) {
  const router = useRouter()
  const soon = isClosingSoon(job.closingDate)
  const fresh = isNew(job.datePosted)
  const initials = getInitials(job.employer)
  const ramp = getAvatarRamp(job.employer)

  const handleAnalyse = () => {
    const basePath = cosMode ? '/job/cos' : '/jobs'
    const returnTo = `${basePath}?analyse=${job.jobRef}`
    if (!isLoggedIn) {
      router.push(`/register?returnTo=${encodeURIComponent(returnTo)}&jobUrl=${encodeURIComponent(job.url)}&jobTitle=${encodeURIComponent(job.title)}`)
      return
    }
    router.push(`/dashboard/new-analysis?jobUrl=${encodeURIComponent(job.url)}&jobTitle=${encodeURIComponent(job.title)}`)
  }

  const tags: { label: string; icon: React.ReactNode }[] = []
  if (job.contractType)   tags.push({ label: job.contractType,   icon: <FileText className="w-3 h-3" /> })
  if (job.workingPattern) tags.push({ label: job.workingPattern, icon: <Clock    className="w-3 h-3" /> })

  return (
    <div className={`rounded-xl border bg-card overflow-hidden transition-colors duration-150 flex flex-col h-full ${
      soon
        ? 'border-[#FAC775] dark:border-[#854F0B] hover:border-[#EF9F27]'
        : 'border-border hover:border-border/80'
    }`}>
      {/* Urgent accent stripe — amber, flat colour, no gradient */}
      {soon && <div className="h-[2px] w-full bg-[#EF9F27]" />}

      <div className="px-5 py-4 space-y-3 flex flex-col flex-1">

        {/* ── Header ── */}
        <div className="flex items-start gap-3">
          {/* Org avatar */}
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-[11px] font-medium shrink-0 border border-border ${ramp.bg} ${ramp.text}`}>
            {initials || <Building2 className="w-3.5 h-3.5" />}
          </div>

          {/* Title + employer + badges */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h3 className="text-[13.5px] font-medium text-foreground leading-snug">{job.title}</h3>
            </div>
            <p className="text-[12px] text-muted-foreground mt-0.5 truncate">{job.employer}</p>
            {(fresh || soon || cosMode) && (
              <div className="flex gap-1.5 mt-1.5 flex-wrap">
                {fresh && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#EAF3DE] text-[#3B6D11] border border-[#C0DD97] dark:bg-[#27500A] dark:text-[#C0DD97] dark:border-[#3B6D11]">
                    New
                  </span>
                )}
                {soon && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#FAEEDA] text-[#854F0B] border border-[#FAC775] dark:bg-[#633806] dark:text-[#FAC775] dark:border-[#854F0B]">
                    Closes soon
                  </span>
                )}
                {sponsorInfo?.isMatch && (
                  <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${
                    sponsorInfo.confidence === 'high'
                      ? 'bg-[#E1F5EE] text-[#085041] border border-[#9FE1CB] dark:bg-[#085041] dark:text-[#9FE1CB] dark:border-[#0F6E56]'
                      : 'bg-[#FAEEDA] text-[#854F0B] border border-[#FAC775] dark:bg-[#633806] dark:text-[#FAC775] dark:border-[#854F0B]'
                  }`}>
                    <Globe className="w-2.5 h-2.5" /> {sponsorInfo.confidence === 'high' ? 'Licensed UKVI Sponsor' : 'Possible UKVI Sponsor'}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* ── Meta ── */}
        <div className="flex flex-col gap-1.5">
          {job.location && (
            <span className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
              <MapPin className="w-3 h-3 shrink-0" /> <span className="truncate">{job.location}</span>
            </span>
          )}
          {job.salary && job.salary !== 'Not specified' && (
            <span className="flex items-center gap-1.5 text-[12px] text-[#0F6E56] dark:text-[#5DCAA5] font-medium">
              <PoundSterling className="w-3 h-3 shrink-0" /> <span className="truncate">{job.salary}</span>
            </span>
          )}
          {job.datePosted && (
            <span className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
              <Calendar className="w-3 h-3 shrink-0" /> Posted {job.datePosted}
            </span>
          )}
          {job.closingDate && (
            <span className={`flex items-center gap-1.5 text-[12px] font-medium ${
              soon
                ? 'text-[#854F0B] dark:text-[#FAC775]'
                : 'text-muted-foreground'
            }`}>
              <Clock className="w-3 h-3 shrink-0" /> Closes {job.closingDate}
            </span>
          )}
        </div>

        {/* Spacer pushes footer down so cards align in the grid */}
        <div className="flex-1" />

        {/* ── Divider ── */}
        <div className="border-t border-border" />

        {/* ── Tags ── */}
        {(tags.length > 0 || job.jobRef) && (
          <div className="flex flex-wrap gap-1.5">
            {tags.map(t => (
              <span
                key={t.label}
                className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded-md bg-muted text-muted-foreground border border-border"
              >
                {t.icon} {t.label}
              </span>
            ))}
            {job.jobRef && (
              <span className="inline-flex items-center text-[10.5px] px-2 py-1 rounded-md bg-muted text-muted-foreground/50 font-mono border border-border tracking-wide">
                {job.jobRef}
              </span>
            )}
          </div>
        )}

        {/* ── Actions ── */}
        <div className="flex items-center gap-2">
          <a
            href={job.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-[12px] font-medium text-muted-foreground hover:text-foreground hover:border-border/80 transition-colors"
          >
            View <ExternalLink className="w-3 h-3" />
          </a>
          <button
            onClick={handleAnalyse}
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-foreground text-background text-[12px] font-medium hover:opacity-85 transition-opacity"
          >
            <Sparkles className="w-3.5 h-3.5" /> Analyse
          </button>
        </div>

      </div>
    </div>
  )
}

function JobsPageContent({ isLoggedIn, cosMode = false }: { isLoggedIn: boolean; cosMode?: boolean }) {
  const searchParams = useSearchParams()
  const router = useRouter()

  const [keyword,    setKeyword]    = useState(searchParams.get('keyword')  ?? '')
  const [location,   setLocation]   = useState(searchParams.get('location') ?? '')
  const [page,       setPage]       = useState(Number(searchParams.get('page') ?? '1'))
  const [jobs,       setJobs]       = useState<Job[]>([])
  const [total,      setTotal]      = useState(0)
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState<string | null>(null)
  const [hasSearched, setHasSearched] = useState(false)

  // COS mode: map of employer name -> sponsor check result, looked up after search results arrive
  const [sponsorInfo, setSponsorInfo] = useState<Record<string, SponsorInfo>>({})
  const [checkingSponsors, setCheckingSponsors] = useState(false)

  const basePath = cosMode ? '/job/cos' : '/jobs'

  const checkSponsors = async (jobsList: Job[]) => {
    if (!cosMode) return
    setCheckingSponsors(true)
    const uniqueEmployers = Array.from(new Set(jobsList.map(j => j.employer).filter(Boolean)))
    const results: Record<string, SponsorInfo> = {}
    // Check sequentially in small batches to avoid hammering the DB
    for (const employer of uniqueEmployers) {
      try {
        const res = await fetch(`/api/sponsors/check?employer=${encodeURIComponent(employer)}`)
        const data = await res.json()
        results[employer] = data
      } catch {
        results[employer] = { isMatch: false, confidence: 'none' }
      }
    }
    setSponsorInfo(results)
    setCheckingSponsors(false)
  }

  const runSearch = async (k = keyword, l = location, p = page) => {
    setLoading(true); setError(null); setSponsorInfo({})
    try {
      const params = new URLSearchParams()
      if (k) params.set('keyword', k)
      if (l) params.set('location', l)
      if (p > 1) params.set('page', String(p))

      const res  = await fetch(`/api/jobs/search?${params.toString()}`)
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? 'Search failed')

      let jobsList = data.jobs ?? []

      // NHS Jobs ignores ?location= server-side — filter here after parsing
      if (l && jobsList.length > 0) {
        const tokens = l.toLowerCase().trim().split(/[,\s]+/).filter((w: string) => w.length >= 2)
        jobsList = jobsList.filter((j: Job) =>
          tokens.some((token: string) =>
            (j.location + ' ' + j.employer).toLowerCase().includes(token)
          )
        )
      }

      setJobs(jobsList)
      setTotal(Number(data.total ?? jobsList.length ?? 0))
      setHasSearched(true)

      router.push(`${basePath}?${params.toString()}`, { scroll: false })

      // After results load, cross-check employers against the UKVI register (COS mode only)
      if (cosMode) checkSponsors(jobsList)
    } catch (e: any) {
      setError(e.message)
      setJobs([])
    } finally { setLoading(false) }
  }

  useEffect(() => {
    if (searchParams.get('keyword') || searchParams.get('location')) {
      runSearch(
        searchParams.get('keyword')  ?? '',
        searchParams.get('location') ?? '',
        Number(searchParams.get('page') ?? '1')
      )
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setPage(1)
    runSearch(keyword, location, 1)
  }

  const changePage = (newPage: number) => {
    setPage(newPage)
    runSearch(keyword, location, newPage)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="space-y-4">

      {/* ── Search form ── */}
      <form
        onSubmit={handleSubmit}
        className="rounded-xl border border-border bg-card p-5 space-y-4"
      >
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="relative">
            <Stethoscope className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <input
              value={keyword}
              onChange={e => setKeyword(e.target.value)}
              placeholder="Job title or keyword"
              className="w-full bg-muted border border-border rounded-lg pl-9 pr-4 py-2 text-[13px] text-foreground placeholder-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <input
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="City or postcode (e.g. London, SW1)"
              className="w-full bg-muted border border-border rounded-lg pl-9 pr-4 py-2 text-[13px] text-foreground placeholder-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2 rounded-lg bg-foreground text-background text-[13px] font-medium inline-flex items-center gap-2 disabled:opacity-50 hover:opacity-85 transition-opacity"
          >
            {loading
              ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Searching…</>
              : <><Search className="w-3.5 h-3.5" /> Search NHS jobs</>
            }
          </button>
          <div className="flex flex-wrap gap-2">
            {['Phlebotomist', 'Staff Nurse', 'Healthcare Assistant', 'Radiographer'].map(s => (
              <button
                key={s}
                type="button"
                onClick={() => { setKeyword(s); runSearch(s, location, 1) }}
                className="text-[12px] px-3 py-1.5 rounded-full border border-border text-muted-foreground hover:text-foreground hover:border-border/80 transition-colors"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </form>

      {/* ── COS explanation / NHS Scotland callout ── */}
      {cosMode ? (
        <div className="space-y-2">
          <div className="rounded-lg border border-[#9FE1CB] dark:border-[#0F6E56] bg-[#E1F5EE]/40 dark:bg-[#085041]/20 px-4 py-3 space-y-1">
            <p className="text-[12px] text-foreground font-medium flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 shrink-0 text-[#0F6E56] dark:text-[#5DCAA5]" />
              Results are cross-checked against the official UKVI Register of Licensed Sponsors
            </p>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              A badge means the <strong>employer organisation</strong> holds a valid Skilled Worker sponsor licence — it does not guarantee this specific role meets salary or skill-level requirements for sponsorship. Always confirm directly with the employer before applying.
            </p>
          </div>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <p className="text-[12px] text-muted-foreground">
              Looking for <strong className="text-foreground font-medium">all NHS jobs</strong>, not just sponsorship roles?
            </p>
            <Link
              href="/jobs"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-[12px] font-medium text-foreground hover:border-border/80 transition-colors shrink-0"
            >
              All NHS jobs <ExternalLink className="w-3 h-3" />
            </Link>
          </div>
        </div>
      ) : (
        <div className="rounded-lg border border-[#9FE1CB] dark:border-[#0F6E56] bg-[#E1F5EE]/40 dark:bg-[#085041]/20 px-4 py-2.5 flex items-center justify-between gap-4 flex-wrap">
          <p className="text-[12px] text-muted-foreground flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 shrink-0 text-[#0F6E56] dark:text-[#5DCAA5]" />
            Need <strong className="text-foreground font-medium">visa sponsorship</strong>? Browse NHS roles offering Skilled Worker sponsorship.
          </p>
          <Link
            href="/job/cos"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0F6E56] hover:bg-[#0C5A46] text-white text-[12px] font-medium transition-colors shrink-0"
          >
            COS jobs <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
      )}

      {/* ── NHS Scotland callout ── */}
      <div className="rounded-lg border border-border bg-muted/40 px-4 py-2.5 flex items-center justify-between gap-4 flex-wrap">
        <p className="text-[12px] text-muted-foreground">
          🏴󠁧󠁢󠁳󠁣󠁴󠁿 Looking for roles in{' '}
          <strong className="text-foreground font-medium">NHS Scotland</strong>?
          {' '}Search Jobtrain directly — then paste the job description into our analyser.
        </p>
        <a
          href="https://jobs.scot.nhs.uk/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-[12px] font-medium text-foreground hover:border-border/80 transition-colors shrink-0"
        >
          NHS Scotland jobs <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      {/* ── Error ── */}
      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
          <p className="text-[13px] text-destructive">{error}</p>
        </div>
      )}

      {/* ── Results ── */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-5 h-5 text-primary animate-spin" />
        </div>
      ) : hasSearched ? (
        jobs.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card/50 p-12 text-center">
            <Search className="w-7 h-7 text-muted-foreground mx-auto mb-3" />
            <p className="text-[13px] text-muted-foreground">No jobs found. Try a different keyword or location.</p>
          </div>
        ) : (
          <div className="space-y-3">

            <p className="text-[12px] text-muted-foreground flex items-center gap-2">
              <span>
                Showing {jobs.length}
                {total > jobs.length && (
                  <>
                    {' '}of{' '}
                    <strong className="text-foreground font-medium">
                      {Number(total).toLocaleString()}
                    </strong>
                  </>
                )} jobs
              </span>
              {cosMode && checkingSponsors && (
                <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Loader2 className="w-3 h-3 animate-spin" /> Checking UKVI register...
                </span>
              )}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {jobs.map(job => <JobCard key={job.jobRef} job={job} isLoggedIn={isLoggedIn} cosMode={cosMode} sponsorInfo={sponsorInfo[job.employer]} />)}
            </div>

            {total > jobs.length && (
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => changePage(Math.max(1, page - 1))}
                  disabled={page <= 1}
                  className="p-2 rounded-lg border border-border text-muted-foreground hover:text-foreground disabled:opacity-30 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-[13px] text-muted-foreground">Page {page}</span>
                <button
                  onClick={() => changePage(page + 1)}
                  className="p-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )
      ) : (
        <div className="rounded-xl border border-dashed border-border bg-card/50 p-12 text-center space-y-3">
          <Search className="w-7 h-7 text-muted-foreground mx-auto" />
          <p className="text-[13px] text-muted-foreground">
            {cosMode ? 'Searching for NHS roles offering visa sponsorship...' : 'Search NHS jobs by title or location to get started.'}
          </p>
        </div>
      )}

    </div>
  )
}

export function JobsClient({ isLoggedIn = false, cosMode = false }: { isLoggedIn?: boolean; cosMode?: boolean }) {
  return (
    <div className="min-h-screen bg-background">

      <Navbar />

      <div className="max-w-5xl mx-auto px-4 py-10">
        <div className="mb-8">
          <Link
            href={cosMode ? "/jobs" : "/"}
            className="text-[12px] text-muted-foreground hover:text-foreground transition-colors mb-4 inline-flex items-center gap-1"
          >
            {cosMode ? '← All NHS jobs' : '← Home'}
          </Link>
          {cosMode ? (
            <>
              <h1 className="text-2xl font-bold text-foreground tracking-tight flex items-center gap-2">
                <Globe className="w-6 h-6 text-[#0F6E56] dark:text-[#5DCAA5]" /> NHS jobs with visa sponsorship
              </h1>
              <p className="text-[13px] text-muted-foreground mt-1 max-w-md leading-relaxed">
                Roles across England, Wales and Northern Ireland where employers have indicated Skilled Worker visa sponsorship is available.
              </p>
            </>
          ) : (
            <>
              <h1 className="text-2xl font-bold text-foreground tracking-tight">Search NHS jobs</h1>
              <p className="text-[13px] text-muted-foreground mt-1 max-w-md leading-relaxed">
                Live vacancies across England, Wales and Northern Ireland. Find a role, then get an instant AI analysis of your application chances.
              </p>
            </>
          )}
        </div>

        <Suspense fallback={
          <div className="flex justify-center py-20">
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
          </div>
        }>
          <JobsPageContent isLoggedIn={isLoggedIn} cosMode={cosMode} />
        </Suspense>
      </div>

    </div>
  )
}